"""PTMAE: Pure Python Transactional Micro-Banking & Audit Engine.

Python 3.x; imports are limited to random and datetime as allowed by the SRS.
Run this file directly to see demonstrations, then use the interactive CLI.
"""

import random
import datetime


# ============================================================================
# Module 1 — State Control Engine and Trajectory Guards (Unit 1)
# ============================================================================

def compound_interest(principal, annual_rate_percent, periods):
    """Return compound interest using arithmetic operators and an explicit loop."""
    if principal < 0 or annual_rate_percent < 0 or periods < 0:
        raise ValueError("Principal, rate, and periods must be non-negative.")
    rate = annual_rate_percent / 100
    factor = 1 + rate
    amount = principal
    count = 0
    while count < periods:
        amount = amount * factor
        count += 1
    return amount - principal


def penalty_fee(amount, penalty_rate_percent, fixed_fee=0):
    """Calculate a penalty using arithmetic operators only."""
    if amount < 0 or penalty_rate_percent < 0 or fixed_fee < 0:
        raise ValueError("Penalty inputs must be non-negative.")
    return amount * (penalty_rate_percent / 100) + fixed_fee


def trajectory_guard(transactions, starting_balance, safety_threshold, terminate=False):
    """Apply transactions until balance is unsafe or termination is requested."""
    balance = starting_balance
    applied = []
    for transaction in transactions:
        # Short-circuit evaluation makes either condition stop the sequence.
        if balance < safety_threshold or terminate:
            break
        if isinstance(transaction, (int, float)):
            balance += transaction
            applied.append(transaction)
        else:
            print("Trajectory stopped: invalid transaction value.")
            break
        if balance < safety_threshold:
            break
    return balance, applied


def command_loop():
    """Run the nested command loop until the explicit 'exit' command."""
    print("\nPTMAE command line. Commands: interest, penalty, guard, help, exit")
    running = True
    while running:
        command = input("PTMAE> ").strip().lower()
        handled = False
        while not handled:
            if command == "exit":
                print("Exiting PTMAE CLI.")
                running = False
                handled = True
            elif command == "help":
                print("interest | penalty | guard | help | exit")
                handled = True
            elif command == "interest":
                try:
                    principal = float(input("Principal: "))
                    rate = float(input("Annual rate (%): "))
                    periods = int(input("Periods: "))
                    print("Interest:", round(compound_interest(principal, rate, periods), 2))
                except (ValueError, EOFError) as error:
                    print("Invalid interest input:", error)
                handled = True
            elif command == "penalty":
                try:
                    amount = float(input("Amount: "))
                    rate = float(input("Penalty rate (%): "))
                    fixed = float(input("Fixed fee (0 if none): "))
                    print("Penalty:", round(penalty_fee(amount, rate, fixed), 2))
                except (ValueError, EOFError) as error:
                    print("Invalid penalty input:", error)
                handled = True
            elif command == "guard":
                try:
                    start = float(input("Starting balance: "))
                    threshold = float(input("Safety threshold: "))
                    raw = input("Transactions, comma-separated (e.g. 200,-50,25): ")
                    transactions = []
                    # This CLI input is not the required raw-log parser.
                    for item in raw.split(","):
                        transactions.append(float(item.strip()))
                    balance, applied = trajectory_guard(transactions, start, threshold)
                    print("Applied:", applied, "Final balance:", balance)
                except (ValueError, EOFError) as error:
                    print("Invalid guard input:", error)
                handled = True
            else:
                print("Unknown command. Type 'help' to see commands.")
                handled = True


# ============================================================================
# Module 2 — Native Log Parser and Closure Mechanics (Unit 2)
# ============================================================================

def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Parse one delimited line manually; supports quoted fields and doubled quotes."""
    tokens = []
    token = ""
    in_quotes = False
    index = 0
    length = len(line)
    while index < length:
        char = line[index]
        if char == quote_char:
            if in_quotes and index + 1 < length and line[index + 1] == quote_char:
                token += quote_char
                index += 2
                continue
            in_quotes = not in_quotes
        elif char == delimiter and not in_quotes:
            tokens.append(token)
            token = ""
        else:
            token += char
        index += 1
    if in_quotes:
        raise ValueError("Unclosed quoted field.")
    tokens.append(token.rstrip("\r\n"))
    return tokens


def create_audit_filter(threshold):
    """Return a validator whose independent closure counts accepted audit records."""
    audited_count = 0

    def validate(record):
        """Accept records whose numeric amount is at least the threshold."""
        nonlocal audited_count
        try:
            amount = float(record[2])
        except (ValueError, TypeError, IndexError):
            return False
        if amount >= threshold:
            audited_count += 1
            return True
        return False

    def count():
        """Return the count maintained by this filter's enclosing scope."""
        return audited_count

    validate.count = count
    return validate


def build_positional_filters(criteria):
    """Build lambdas that test the criterion at each positional index safely."""
    filters = []
    for k in range(len(criteria)):
        filters.append(lambda transaction, k=k: len(transaction) > k and transaction[k] == criteria[k])
    return filters


# ============================================================================
# Module 3 — Data Inversion and In-Place Processing (Unit 3)
# ============================================================================

def build_reverse_index(raw_db):
    """Map each service tag to sorted, unique (account_id, branch_id) tuples."""
    pairs = {
        service: sorted({(account_id, branch_id)
                         for branch_id, accounts in raw_db.items()
                         for account_id, tags in accounts
                         for tag in tags if tag == service})
        for service in {tag for accounts in raw_db.values()
                        for account_id, tags in accounts for tag in tags}
    }
    return pairs


def clean_transaction_queue(data_list):
    """Clean a heterogeneous queue in place without rebinding its top-level list."""
    index = 0
    while index < len(data_list):
        item = data_list[index]
        if isinstance(item, tuple):
            data_list[index] = list(item)
            item = data_list[index]
        if isinstance(item, set):
            evens = set()
            for value in item:
                if isinstance(value, int) and value % 2 == 0:
                    evens.add(value)
            data_list[index] = item - evens
        elif isinstance(item, list):
            item.sort(reverse=True)
        index += 1

    # Remove duplicate primitive values by scanning and deleting in place.
    index = 0
    while index < len(data_list):
        current = data_list[index]
        if isinstance(current, (str, int, float, bool, type(None))):
            later = index + 1
            while later < len(data_list):
                other = data_list[later]
                if isinstance(other, (str, int, float, bool, type(None))) and type(other) is type(current) and other == current:
                    del data_list[later]
                else:
                    later += 1
        index += 1
    return data_list


# ============================================================================
# Module 4 — Transactional File Modifier and Error Logger (Unit 4)
# ============================================================================

class BaseSystemError(Exception):
    """Base class for application-specific errors."""


class CorruptedRecordError(BaseSystemError):
    """Raised when a stored account record is malformed."""


class OutOfBoundsError(BaseSystemError):
    """Raised when a requested value is outside the permitted bounds."""


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot cover a settlement."""


def _shift_tail(file_object, start, delta):
    """Shift bytes represented by ASCII text records in chunks using seek/read/write."""
    file_object.seek(0, 2)
    end = file_object.tell()
    if delta > 0:
        position = end
        while position > start:
            chunk_start = position - 4096
            if chunk_start < start:
                chunk_start = start
            file_object.seek(chunk_start)
            chunk = file_object.read(position - chunk_start)
            file_object.seek(chunk_start + delta)
            file_object.write(chunk)
            position = chunk_start
    elif delta < 0:
        position = start
        while position < end:
            file_object.seek(position)
            chunk = file_object.read(4096)
            if not chunk:
                break
            file_object.seek(position + delta)
            file_object.write(chunk)
            position += len(chunk)
        file_object.truncate(end + delta)


def update_account_record(account_id, new_type, new_balance, database="accounts.db"):
    """Update one record in r+ mode and shift the trailing file content in chunks."""
    if new_balance < 0:
        raise OutOfBoundsError("Stored balance cannot be negative.")
    target_start = None
    old_record = None
    line_number = 0
    try:
        with open(database, "r+", encoding="utf-8", newline="") as file_object:
            while True:
                start = file_object.tell()
                line = file_object.readline()
                if line == "":
                    break
                line_number += 1
                try:
                    fields = parse_raw_log_line(line.rstrip("\r\n"))
                    if len(fields) != 3:
                        raise CorruptedRecordError("Expected three fields.")
                    float(fields[2])
                    if fields[1] not in ("SAVINGS", "CURRENT", "CREDIT"):
                        raise CorruptedRecordError("Unknown account type.")
                except (ValueError, CorruptedRecordError) as error:
                    with open("corrupted.log", "a", encoding="utf-8") as log_file:
                        log_file.write("Line " + str(line_number) + ": " + line.rstrip("\r\n") + " | " + str(error) + "\n")
                    continue
                if fields[0] == account_id:
                    target_start = start
                    old_record = line
                    break
            if target_start is None:
                raise OutOfBoundsError("Account ID was not found: " + account_id)

            new_record = account_id + "," + new_type + "," + format(new_balance, ".2f")
            if old_record.endswith("\n"):
                new_record += "\n"
            old_length = len(old_record)
            new_length = len(new_record)
            tail_start = target_start + old_length
            delta = new_length - old_length
            if delta != 0:
                _shift_tail(file_object, tail_start, delta)
            file_object.seek(target_start)
            file_object.write(new_record)
            file_object.seek(0, 2)
            file_object.truncate()
        with open("ledger.txt", "a", encoding="utf-8") as ledger:
            ledger.write(datetime.datetime.now().isoformat(timespec="seconds") + " | UPDATED | " + account_id + " | " + format(new_balance, ".2f") + "\n")
        return True
    except BaseSystemError:
        raise
    except (OSError, UnicodeError) as error:
        raise BaseSystemError("File operation failed: " + str(error))


def process_database_updates(database="accounts.db"):
    """Validate sample update requests and report processed/rejected counts."""
    processed = 0
    rejected = 0
    requests = [("Acc101", "SAVINGS", 5400.0), ("Acc103", "CURRENT", 1750.0), ("MISSING", "SAVINGS", 300.0)]
    try:
        for account_id, account_type, balance in requests:
            try:
                update_account_record(account_id, account_type, balance, database)
            except (BaseSystemError, ValueError, OSError) as error:
                rejected += 1
                with open("corrupted.log", "a", encoding="utf-8") as log_file:
                    log_file.write("Update rejected for " + account_id + ": " + str(error) + "\n")
            else:
                processed += 1
    except Exception as error:
        print("Unexpected update processing error:", error)
    finally:
        print("File update summary — processed:", processed, "rejected:", rejected)
    return processed, rejected


def ensure_demo_database(database="accounts.db"):
    """Create a small demonstration database only when it does not exist."""
    try:
        with open(database, "r", encoding="utf-8") as existing:
            existing.readline()
    except FileNotFoundError:
        with open(database, "w", encoding="utf-8", newline="") as created:
            created.write("Acc101,SAVINGS,5200.00\n")
            created.write("Acc102,CURRENT,2300.00\n")
            created.write("Acc103,CREDIT,6000.00\n")
            created.write("Acc104,SAVINGS,1800.00\n")


# ============================================================================
# Module 5 — Object-Oriented Architecture and Polymorphic Engine (Unit 5)
# ============================================================================

class Account:
    """Base bank account with encapsulated balance and shared account count."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        """Create an account after validating its identifier and opening balance."""
        if not isinstance(account_id, str) or account_id == "":
            raise TypeError("account_id must be a non-empty string.")
        self._account_id = account_id
        self.__balance = self._validate_balance(balance)
        Account.total_accounts += 1

    @staticmethod
    def _validate_balance(value):
        """Return a valid non-negative numeric balance."""
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("Balance must be an int or float.")
        if value < 0:
            raise OutOfBoundsError("Balance cannot be negative.")
        return float(value)

    def get_balance(self):
        """Return the current balance."""
        return self.__balance

    def set_balance(self, value):
        """Set the balance after validating its type and range."""
        self.__balance = self._validate_balance(value)

    def _set_net_balance(self, value):
        """Protected helper for subclasses that legitimately allow a negative net balance."""
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("Balance must be an int or float.")
        self.__balance = float(value)

    def get_account_id(self):
        """Return the protected account identifier through a public getter."""
        return self._account_id

    def process_settlement(self, amount):
        """Default settlement deducts an amount if the balance is sufficient."""
        amount = self._validate_balance(amount)
        if amount > self.__balance:
            raise InsufficientBalanceError("Insufficient balance.")
        self.__balance -= amount
        return self.__balance


class SavingsAccount(Account):
    """Savings account that must retain at least 1000 after settlement."""
    def __init__(self, account_id, balance):
        """Initialise through super() without hardcoding the base class name."""
        super().__init__(account_id, balance)

    def process_settlement(self, amount):
        """Deduct only if the remaining balance is at least 1000."""
        amount = self._validate_balance(amount)
        remaining = self.get_balance() - amount
        if remaining < 1000:
            raise InsufficientBalanceError("Savings account must retain at least 1000.")
        self.set_balance(remaining)
        return self.get_balance()


class CurrentAccount(Account):
    """Current account with a private overdraft limit."""
    def __init__(self, account_id, balance, overdraft_limit=2000):
        """Initialise the account and validate its overdraft limit."""
        super().__init__(account_id, balance)
        self.__overdraft_limit = self._validate_balance(overdraft_limit)

    def process_settlement(self, amount):
        """Allow the balance to go negative only within the overdraft limit."""
        amount = self._validate_balance(amount)
        remaining = self.get_balance() - amount
        if remaining < -self.__overdraft_limit:
            raise OutOfBoundsError("Overdraft limit exceeded.")
        if remaining < 0:
            self._set_net_balance(remaining)
        else:
            self.set_balance(remaining)
        return self.get_balance()


class CreditAccount(Account):
    """Credit account that applies a 2.5 percent surcharge to each settlement."""
    def __init__(self, account_id, balance, credit_limit=None):
        """Initialise the account and its available credit limit."""
        super().__init__(account_id, balance)
        self.__credit_limit = self.get_balance() if credit_limit is None else self._validate_balance(credit_limit)

    def process_settlement(self, amount):
        """Deduct the amount plus a 2.5 percent surcharge against the limit."""
        amount = self._validate_balance(amount)
        total = amount + amount * 2.5 / 100
        if total > self.__credit_limit:
            raise OutOfBoundsError("Credit limit exceeded after surcharge.")
        if total > self.get_balance():
            raise InsufficientBalanceError("Insufficient available credit balance.")
        self.set_balance(self.get_balance() - total)
        self.__credit_limit -= total
        return self.get_balance()


def execute_batch_settlement(account_list, transaction_amount):
    """Settle each account independently and report successful and failed items."""
    successes = 0
    failures = 0
    for account in account_list:
        try:
            new_balance = account.process_settlement(transaction_amount)
        except (BaseSystemError, TypeError, ValueError) as error:
            failures += 1
            print(account.get_account_id(), "FAILED:", error)
        else:
            successes += 1
            print(account.get_account_id(), "settled; remaining balance:", round(new_balance, 2))
    print("Batch summary — successes:", successes, "failures:", failures)
    return successes, failures


# ============================================================================
# Demonstration and entry point
# ============================================================================

def run_demonstrations():
    """Exercise the major requirements from all five modules."""
    print("=" * 68)
    print("PTMAE — demonstration of Units 1–5")
    print("=" * 68)

    print("\n[Module 1] Compound interest and penalty")
    print("Interest on 1000 at 5% for 2 periods:", round(compound_interest(1000, 5, 2), 2))
    print("Penalty on 500 at 3% plus 10:", round(penalty_fee(500, 3, 10), 2))
    print("Trajectory guard:", trajectory_guard([100, -250, 50], 1100, 1000))
    print("Early termination guard:", trajectory_guard([100, 100], 1000, 500, True))

    print("\n[Module 2] Manual parser and closures")
    examples = ['Acc1,DEPOSIT,150', 'Acc2,"UPI, QR",250', 'Acc3,"said ""hello""",300,']
    for example in examples:
        print(example, "=>", parse_raw_log_line(example))
    audit = create_audit_filter(200)
    print("Audit accepted:", audit(["Acc1", "DEPOSIT", "250"]), "count:", audit.count())
    print("Audit rejected:", audit(["Acc2", "UPI", "100"]), "count:", audit.count())
    positional = build_positional_filters(["Acc1", "DEPOSIT"])
    print("Positional filters:", [func(["Acc1", "DEPOSIT", 100]) for func in positional])

    print("\n[Module 3] Reverse index and in-place queue")
    raw_db = {
        "BRANCH_01": [("Acc101", {"DEPOSIT", "UPI"}), ("Acc102", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
    }
    print("Reverse index:", build_reverse_index(raw_db))
    queue = [(1, 2), [3, 1, 2], {1, 2, 4, 5}, 7, 7, "A", "A"]
    original_id = id(queue)
    clean_transaction_queue(queue)
    print("Queue cleaned in place:", queue, "same object:", id(queue) == original_id)

    print("\n[Module 4] File update and exception hierarchy")
    print("Exception inheritance:", issubclass(CorruptedRecordError, BaseSystemError), issubclass(OutOfBoundsError, BaseSystemError), issubclass(InsufficientBalanceError, BaseSystemError))
    ensure_demo_database()
    print("Demo database ready: accounts.db (existing data is preserved).")
    print("Use process_database_updates() to run sample r+ update requests.")

    print("\n[Module 5] Polymorphic settlement and name mangling")
    accounts = [SavingsAccount("SAV-1", 5000), CurrentAccount("CUR-1", 1500, 1000), CreditAccount("CR-1", 4000)]
    print("Total accounts created:", Account.total_accounts)
    print("Mangled balance demo:", accounts[0]._Account__balance)
    try:
        print(accounts[0].__balance)
    except AttributeError:
        print("Direct obj.__balance access correctly raises AttributeError.")
    execute_batch_settlement(accounts, 500)


def main():
    """Run demonstrations, then offer the optional interactive command loop."""
    run_demonstrations()
    while True:
        choice = input("\nChoose: [1] CLI commands, [2] file-update demo, [3] exit: ").strip()
        if choice == "1":
            command_loop()
        elif choice == "2":
            ensure_demo_database()
            process_database_updates()
        elif choice == "3":
            print("PTMAE finished.")
            break
        else:
            print("Please enter 1, 2, or 3.")


if __name__ == "__main__":
    main()
