# PTMAE — Project Documentation

**Project:** Pure Python Transactional Micro-Banking & Audit Engine (PTMAE)  
**Document ID:** PTMAE-SRS-1.0  
**Course:** Python Programming (Units 1–5)  
**Main source file:** `main.py`

## 1. Project overview

PTMAE is a command-line banking demonstration written using Python's built-in language features. It demonstrates arithmetic calculations, a manually written delimited-log parser, closures and lambdas, reverse indexing, in-place list processing, text-file record updates, custom exceptions, classes, encapsulation, inheritance, and polymorphism.

It is a local, single-process educational program. It is not a real banking product and must not be used to store real financial information.

## 2. Files

- `main.py` — all five modules and demonstration code.
- `document.md` — this project explanation, architecture, scope table, and compliance checklist.
- `accounts.db` — created by the demonstration only if it does not already exist.
- `ledger.txt` — append-only record of accepted account updates.
- `corrupted.log` — append-only record of invalid records and rejected updates.

The three data/log files are runtime files, not required source deliverables. Keep a backup of any existing `accounts.db` before testing updates.

## 3. Run the project

1. Install Python 3.x if it is not already installed.
2. Put `main.py` and `document.md` in the same folder.
3. Open a terminal in that folder.
4. Run `python main.py` (on some systems use `python3 main.py`).
5. Read the demonstrations. Choose `1` for the CLI, `2` to run sample file-update requests, or `3` to exit.

CLI commands:

| Command | Purpose |
|---|---|
| `interest` | Calculate compound interest using a loop. |
| `penalty` | Calculate a percentage penalty plus a fixed fee. |
| `guard` | Apply transactions until the safety threshold is crossed. |
| `help` | Display command names. |
| `exit` | Exit the command loop. |

## 4. Architecture diagram

```text
                         +---------------------+
                         |      main()         |
                         +----------+----------+
                                    |
             +----------------------+----------------------+
             |                      |                      |
     +-------v-------+      +-------v--------+     +-------v--------+
     | Module 1      |      | Module 2       |     | Module 3       |
     | CLI, interest,|      | Manual parser, |     | Reverse index, |
     | penalty, guard|      | closures, lambda|    | queue cleanup  |
     +---------------+      +----------------+     +----------------+
             |                      |                      |
             +----------------------+----------------------+
                                    |
                    +---------------v----------------+
                    | Module 4: r+ file updates,      |
                    | ledger, corrupted log, errors   |
                    +---------------+----------------+
                                    |
                    +---------------v----------------+
                    | Module 5: Account hierarchy,    |
                    | settlement, batch processing    |
                    +--------------------------------+
```

## 5. Module descriptions

### Module 1 — State control and trajectory guards

- `compound_interest()` uses repeated multiplication in a loop; it does not import or use `math`.
- `penalty_fee()` uses arithmetic operators.
- `trajectory_guard()` checks the safety threshold and termination flag using short-circuit `or` logic and stops early.
- `command_loop()` uses nested `while` loops and keeps running until `exit` is entered.

### Module 2 — Manual parser and closures

- `parse_raw_log_line()` scans each character by index. It handles delimiters inside quoted fields, doubled quote characters, empty fields, and trailing delimiters.
- `create_audit_filter()` returns a nested validator. `nonlocal` updates an independent audit counter for each filter instance. The counter can be read with `validator.count()`.
- `build_positional_filters()` binds `k=k` in each lambda so each function checks its own position.

### Module 3 — Reverse index and in-place queue

- `build_reverse_index()` creates a mapping from each service tag to alphabetically sorted, unique `(Account_ID, Branch_ID)` tuples.
- `clean_transaction_queue()` mutates the supplied top-level list rather than assigning a new list to the parameter. Tuples become lists, embedded lists are sorted descending, even integer values are removed from sets, and duplicate primitive values are removed by scanning and deleting by index.

### Module 4 — File updates and errors

- `BaseSystemError` is the parent of `CorruptedRecordError`, `OutOfBoundsError`, and `InsufficientBalanceError`.
- `update_account_record()` opens `accounts.db` in `r+` mode, validates records, uses `tell()` and `seek()`, and shifts following content in chunks if a record changes length. It appends accepted changes to `ledger.txt`.
- Invalid records and rejected update requests are appended to `corrupted.log` with context.
- `process_database_updates()` uses `try`, `except`, `else`, and `finally`, and reports processed and rejected totals.

The chunk-shift implementation assumes the simple account database format shown in the SRS: ASCII account IDs/types, comma delimiters, numeric balances, and one record per line. Do not use this educational file updater as a production database engine.

### Module 5 — Object-oriented engine

- `Account` stores a private `__balance`, protected `_account_id`, and class attribute `total_accounts`.
- Public getters/setters validate balance values.
- `SavingsAccount` retains at least 1000 after a settlement.
- `CurrentAccount` supports a private overdraft limit.
- `CreditAccount` applies a 2.5% surcharge and checks its available credit limit.
- `execute_batch_settlement()` wraps each account's settlement in its own `try-except`, so one failed account does not prevent later accounts from being processed.
- The demonstration shows name mangling with `_Account__balance` and the expected failure of direct `obj.__balance` access.

## 6. Class diagram

```text
                    Account
            +-----------------------+
            | - __balance          |
            | # _account_id        |
            | + total_accounts     |
            +-----------+-----------+
                        |
          +-------------+--------------+
          |             |              |
  +-------v------+ +----v---------+ +--v-------------+
  | SavingsAccount| |CurrentAccount| | CreditAccount  |
  +--------------+ +--------------+ +----------------+
  | settlement   | | settlement   | | settlement     |
  | min 1000     | | overdraft    | | 2.5% surcharge|
  +--------------+ +--------------+ +----------------+
```

Legend: `-` private, `#` protected, `+` public.

## 7. State and scope tracking table

| Item | Scope / visibility | Purpose | How it is used |
|---|---|---|---|
| `running` | Local to `command_loop()` | Controls the outer CLI loop | Set to `False` only for `exit` |
| `audited_count` | Enclosing local captured by closure | Counts accepted records | Updated with `nonlocal` in validator |
| `k` | Lambda default argument | Freezes each positional index | `lambda transaction, k=k: ...` |
| `Account.total_accounts` | Class attribute | Counts constructed accounts | Incremented by `Account.__init__()` |
| `Account.__balance` | Private, name-mangled instance attribute | Stores account balance | Accessed through getter/setter; mangled name used only in demonstration/helper |
| `CurrentAccount.__overdraft_limit` | Private, name-mangled instance attribute | Maximum overdraft | Checked by current-account settlement |
| `CreditAccount.__credit_limit` | Private, name-mangled instance attribute | Tracks available credit limit | Reduced after a successful settlement |
| Module-level variables | No mutable global state used to pass closure data | Keep state explicit | State is passed as arguments or held by objects/closures |

## 8. Compliance checklist (Units 1–5)

- [x] **Unit 1:** nested `while` loops, conditionals, arithmetic-only interest and penalty, early-stopping trajectory guard.
- [x] **Unit 2:** manual index-based parser, quote handling, closure with `nonlocal`, lambda default argument `k=k`.
- [x] **Unit 3:** nested/dictionary comprehensions, reverse index, in-place top-level queue mutation, index-based duplicate deletion.
- [x] **Unit 4:** custom exception hierarchy, `r+` mode, `tell()`/`seek()`/`truncate()`, chunk-based tail shifting, `try-except-else-finally`, dual logs.
- [x] **Unit 5:** private/protected/class attributes, validation through accessors, `super()`, overridden settlement methods, isolated batch processing.
- [x] Only `random` and `datetime` are imported.
- [x] No third-party packages or database engine are used.
- [x] Demonstration code is included in `main.py`.

## 9. Important test cases

| Test | Expected result |
|---|---|
| `parse_raw_log_line('A,"UPI, QR",250')` | `['A', 'UPI, QR', '250']` |
| `parse_raw_log_line('A,"said ""hello""",300,')` | Doubled quotes become one literal quote; final field is empty |
| `id(queue)` before and after `clean_transaction_queue(queue)` | Same object ID |
| Audit filter called with amount at/above threshold | Returns `True` and increments its own count |
| Savings settlement leaves less than 1000 | Raises `InsufficientBalanceError` |
| Batch contains one rejected account | Remaining accounts are still attempted |
| Update request references an unknown account | Rejected and logged; processing continues |

## 10. Limitations and notes

This is a syllabus-focused assignment implementation. The file update logic is designed for the SRS's simple text records and small demonstration files, not concurrent or production financial use. `accounts.db` is created only when absent; if it already exists, the demo preserves it. Make a backup before running the sample update option because successful updates modify the file.
