"""
PTMAE - Pure Python Transactional Micro-Banking & Audit Engine
Python 3.x; only optional allowed imports are datetime and random.
"""

from datetime import datetime


# ============================================================
# MODULE 1: State Control Engine and Trajectory Guards (Unit 1)
# ============================================================

def compound_interest(principal, rate_percent, periods):
    """Calculate compound interest using arithmetic operators only."""
    amount = principal
    period = 0
    while period < periods:
        amount = amount * (1 + rate_percent / 100)
        period += 1
    return amount - principal


def penalty_fee(amount, penalty_percent):
    """Calculate a penalty fee using arithmetic operators only."""
    return amount * penalty_percent / 100


def trajectory_guard(balance, transactions, safety_threshold=1000):
    """Stop at once if balance falls below threshold or a stop flag appears."""
    processed = []
    for item in transactions:
        # Each item is (amount, terminate_flag).
        if balance < safety_threshold or item[1]:
            break
        balance += item[0]
        processed.append(item[0])
    return balance, processed


def command_loop():
    """Interactive nested-loop command processor; type help for commands."""
    print("\nPTMAE command loop. Commands: interest, penalty, balance, guard, help, exit")
    while True:
        while True:
            command = input("PTMAE> ").strip().lower()
            if command:
                break
            print("Please enter a command.")
        if command == "exit":
            print("Exiting command loop.")
            break
        elif command == "help":
            print("interest | penalty | balance | guard | exit")
        elif command == "interest":
            try:
                principal = float(input("Principal: "))
                rate = float(input("Annual rate (%): "))
                periods = int(input("Number of periods: "))
                if principal < 0 or rate < 0 or periods < 0:
                    print("Values must be non-negative.")
                else:
                    print("Compound interest:", round(compound_interest(principal, rate, periods), 2))
            except ValueError:
                print("Invalid number. Try again.")
        elif command == "penalty":
            try:
                amount = float(input("Transaction amount: "))
                rate = float(input("Penalty rate (%): "))
                if amount < 0 or rate < 0:
                    print("Values must be non-negative.")
                else:
                    print("Penalty fee:", round(penalty_fee(amount, rate), 2))
            except ValueError:
                print("Invalid number. Try again.")
        elif command == "balance":
            try:
                balance = float(input("Starting balance: "))
                amount = float(input("Transaction amount (+ deposit, - withdrawal): "))
                print("New balance:", balance + amount)
            except ValueError:
                print("Invalid number. Try again.")
        elif command == "guard":
            try:
                balance = float(input("Starting balance: "))
                threshold = float(input("Safety threshold: "))
                raw = input("Transactions as comma-separated amounts (use STOP to terminate): ")
                transactions = []
                for token in raw.split(","):
                    token = token.strip()
                    if token.upper() == "STOP":
                        transactions.append((0, True))
                    elif token:
                        transactions.append((float(token), False))
                final_balance, done = trajectory_guard(balance, transactions, threshold)
                print("Balance:", final_balance, "| processed:", done)
            except ValueError:
                print("Invalid amount. Try again.")
        else:
            print("Invalid command. Type help.")


# ============================================================
# MODULE 2: Native Log Parser and Closure Mechanics (Unit 2)
# ============================================================

def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Parse one delimited line manually, supporting quotes and doubled quotes."""
    tokens = []
    current = ""
    in_quotes = False
    index = 0
    length = len(line)

    while index < length:
        char = line[index]
        if char == quote_char:
            if in_quotes:
                if index + 1 < length and line[index + 1] == quote_char:
                    current += quote_char
                    index += 1
                else:
                    in_quotes = False
            else:
                in_quotes = True
        elif char == delimiter and not in_quotes:
            tokens.append(current)
            current = ""
        else:
            current += char
        index += 1

    tokens.append(current)
    return tokens


def create_audit_filter(threshold):
    """Return a closure that counts accepted audit records independently."""
    audited_count = 0

    def validate(record):
        nonlocal audited_count
        accepted = False
        try:
            accepted = float(record["amount"]) >= threshold
        except (ValueError, TypeError, KeyError):
            accepted = False
        if accepted:
            audited_count += 1
        return accepted

    def get_count():
        """Return the number of accepted records."""
        return audited_count

    validate.get_count = get_count
    return validate


def build_positional_filters(criteria):
    """Build lambda filters without late-binding by binding k=k."""
    filters = []
    for k in range(len(criteria)):
        filters.append(lambda transaction, k=k: (
            k < len(transaction) and transaction[k] == criteria[k]
        ))
    return filters


# ============================================================
# MODULE 3: Data Inversion and In-Place Processing (Unit 3)
# ============================================================

def build_reverse_index(raw_db):
    """Return service -> sorted unique (account ID, branch ID) tuples."""
    reverse = {
        service: sorted({
            (account_id, branch_id)
            for branch_id, records in raw_db.items()
            for account_id, services in records
            if service in services
        })
        for branch_id, records in raw_db.items()
        for account_id, services in records
        for service in services
    }
    return reverse


def clean_transaction_queue(data_list):
    """Clean queue in place; preserve top-level list identity."""
    index = 0
    while index < len(data_list):
        item = data_list[index]

        if isinstance(item, tuple):
            data_list[index] = list(item)
            item = data_list[index]

        if isinstance(item, set):
            evens = set()
            for value in item:
                if isinstance(value, int) and value % 2 == 0:
                    evens.add(value)
            item.difference_update(evens)

        if isinstance(item, list):
            item.sort(reverse=True)

        # Remove duplicate primitive values in the top-level list by scanning
        # and deleting by index; compound containers are not treated as primitives.
        index += 1

    index = 0
    while index < len(data_list):
        value = data_list[index]
        if isinstance(value, (str, int, float, bool, type(None))):
            scan = index + 1
            while scan < len(data_list):
                if type(data_list[scan]) is type(value) and data_list[scan] == value:
                    del data_list[scan]
                else:
                    scan += 1
        index += 1
    return data_list


# ============================================================
# MODULE 4: Transactional File Modifier and Error Logger (Unit 4)
# ============================================================

class BaseSystemError(Exception):
    """Base class for PTMAE system errors."""


class CorruptedRecordError(BaseSystemError):
    """Raised when an account record is malformed."""


class OutOfBoundsError(BaseSystemError):
    """Raised when a transaction violates a permitted bound."""


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot cover a transaction."""


def _shift_file_tail(file_obj, start_position, old_length, new_length):
    """Shift trailing bytes in chunks after a record changes length."""
    chunk_size = 4096
    tail_start = start_position + old_length
    delta = new_length - old_length

    if delta > 0:
        file_obj.seek(0, 2)
        end_position = file_obj.tell()
        position = end_position
        while position > tail_start:
            read_start = position - chunk_size
            if read_start < tail_start:
                read_start = tail_start
            file_obj.seek(read_start)
            chunk = file_obj.read(position - read_start)
            file_obj.seek(read_start + delta)
            file_obj.write(chunk)
            position = read_start
    elif delta < 0:
        file_obj.seek(0, 2)
        end_position = file_obj.tell()
        position = tail_start
        while position < end_position:
            file_obj.seek(position)
            chunk = file_obj.read(chunk_size)
            if not chunk:
                break
            file_obj.seek(position + delta)
            file_obj.write(chunk)
            position += len(chunk)
        file_obj.truncate(end_position + delta)


def update_account_record(account_id, transaction_amount, db_path="accounts.db"):
    """Update a matching account record in r+ mode without rewriting the whole file."""
    processed = 0
    rejected = 0
    found = False

    try:
        with open(db_path, "r+", encoding="utf-8", newline="") as file_obj:
            line_number = 0
            while True:
                start = file_obj.tell()
                line = file_obj.readline()
                if line == "":
                    break
                line_number += 1
                processed += 1
                try:
                    fields = parse_raw_log_line(line.rstrip("\n"))
                    if len(fields) != 3:
                        raise CorruptedRecordError("Expected 3 fields")
                    record_id = fields[0].strip()
                    account_type = fields[1].strip().upper()
                    try:
                        balance = float(fields[2].strip())
                    except ValueError:
                        raise CorruptedRecordError("Balance is not numeric")
                    if account_type not in ("SAVINGS", "CURRENT", "CREDIT"):
                        raise CorruptedRecordError("Unknown account type")

                    if record_id == account_id:
                        new_balance = balance + transaction_amount
                        if new_balance < 0:
                            raise InsufficientBalanceError("Balance cannot become negative")
                        newline = "\n" if line.endswith("\n") else ""
                        updated = "{},{},{:.2f}{}".format(
                            record_id, account_type, new_balance, newline
                        )
                        old_payload_length = len(line)
                        new_payload_length = len(updated)
                        if new_payload_length != old_payload_length:
                            _shift_file_tail(
                                file_obj, start, old_payload_length, new_payload_length
                            )
                        file_obj.seek(start)
                        file_obj.write(updated)
                        found = True
                        with open("ledger.txt", "a", encoding="utf-8") as ledger:
                            ledger.write("{} UPDATED {} by {:.2f}; balance {:.2f}\n".format(
                                datetime.now().isoformat(timespec="seconds"),
                                record_id, transaction_amount, new_balance
                            ))
                        break
                except BaseSystemError as error:
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as log_file:
                        log_file.write("Line {}: {} | {}\n".format(line_number, line.rstrip("\n"), error))
                except (ValueError, TypeError) as error:
                    rejected += 1
                    with open("corrupted.log", "a", encoding="utf-8") as log_file:
                        log_file.write("Line {}: {} | {}\n".format(line_number, line.rstrip("\n"), error))
            if not found:
                raise CorruptedRecordError("Account ID not found: " + account_id)
    except (OSError, BaseSystemError) as error:
        print("File update error:", error)
    else:
        print("Account updated successfully.")
    finally:
        print("Records processed:", processed, "| rejected:", rejected)
    return found


def create_sample_database(db_path="accounts.db"):
    """Create a sample text database only if it does not already exist."""
    try:
        with open(db_path, "r", encoding="utf-8"):
            return
    except OSError:
        pass
    with open(db_path, "w", encoding="utf-8", newline="") as file_obj:
        file_obj.write("Acc101,SAVINGS,5200.00\n")
        file_obj.write("Acc102,CURRENT,2500.00\n")
        file_obj.write("Acc103,CREDIT,9000.00\n")
        file_obj.write("Acc104,SAVINGS,1500.00\n")


# ============================================================
# MODULE 5: Object-Oriented Architecture and Settlement (Unit 5)
# ============================================================

class Account:
    """Base account with encapsulated balance and account identifier."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        self._account_id = str(account_id)
        self.__balance = self._validate_balance(balance)
        Account.total_accounts += 1

    @staticmethod
    def _validate_balance(value):
        """Validate and convert a numeric balance."""
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("Balance must be an integer or float")
        if value < 0:
            raise OutOfBoundsError("Balance cannot be negative")
        return float(value)

    @property
    def balance(self):
        """Get private account balance."""
        return self.__balance

    @balance.setter
    def balance(self, value):
        """Set private account balance after validation."""
        self.__balance = self._validate_balance(value)

    @property
    def account_id(self):
        """Return account identifier."""
        return self._account_id

    @account_id.setter
    def account_id(self, value):
        """Validate and set account identifier."""
        if not isinstance(value, str) or not value:
            raise TypeError("Account ID must be a non-empty string")
        self._account_id = value

    def process_settlement(self, amount):
        """Base settlement implementation."""
        if amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        if amount > self.__balance:
            raise InsufficientBalanceError("Insufficient balance")
        self.__balance -= amount
        return self.__balance


class SavingsAccount(Account):
    """Savings account must retain at least 1000 after settlement."""

    def process_settlement(self, amount):
        """Deduct a transaction while preserving the minimum balance."""
        if amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        if self.balance - amount < 1000:
            raise InsufficientBalanceError("Savings account must retain 1000")
        self.balance = self.balance - amount
        return self.balance


class CurrentAccount(Account):
    """Current account permits overdraft up to its private limit."""

    def __init__(self, account_id, balance, overdraft_limit=2000):
        super().__init__(account_id, balance)
        if overdraft_limit < 0:
            raise OutOfBoundsError("Overdraft limit cannot be negative")
        self.__overdraft_limit = float(overdraft_limit)

    def process_settlement(self, amount):
        """Deduct amount while respecting the overdraft limit."""
        if amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        if self.balance - amount < -self.__overdraft_limit:
            raise InsufficientBalanceError("Overdraft limit exceeded")
        self.balance = self.balance - amount
        return self.balance


class CreditAccount(Account):
    """Credit account charges a 2.5 percent surcharge on settlement."""

    def __init__(self, account_id, balance, credit_limit=10000):
        super().__init__(account_id, balance)
        if credit_limit < 0:
            raise OutOfBoundsError("Credit limit cannot be negative")
        self.__credit_limit = float(credit_limit)

    def process_settlement(self, amount):
        """Apply surcharge and deduct against the available credit limit."""
        if amount < 0:
            raise OutOfBoundsError("Transaction amount must be non-negative")
        total = amount + amount * 2.5 / 100
        if self.balance - total < -self.__credit_limit:
            raise InsufficientBalanceError("Credit limit exceeded")
        self.balance = self.balance - total
        return self.balance


def execute_batch_settlement(account_list, transaction_amount):
    """Settle a mixed account list; isolate each account's errors."""
    successes = []
    failures = []
    for account in account_list:
        try:
            new_balance = account.process_settlement(transaction_amount)
            successes.append((account.account_id, new_balance))
            print("SETTLED", account.account_id, "new balance:", round(new_balance, 2))
        except (BaseSystemError, TypeError, ValueError) as error:
            failures.append((getattr(account, "account_id", "UNKNOWN"), str(error)))
            print("FAILED", getattr(account, "account_id", "UNKNOWN"), "-", error)
    print("Batch summary: successes =", len(successes), ", failures =", len(failures))
    return successes, failures


# ============================================================
# Demonstrations for requirements and test cases
# ============================================================

def run_demonstrations():
    """Exercise representative requirements from all five units."""
    print("=" * 64)
    print("PTMAE DEMONSTRATION")
    print("=" * 64)

    print("\n[Unit 1] Compound interest and penalty")
    print("Interest on 1000 at 5% for 2 periods:", round(compound_interest(1000, 5, 2), 2))
    print("Penalty on 500 at 2%:", penalty_fee(500, 2))
    print("Trajectory guard:", trajectory_guard(1500, [(100, False), (-700, False), (50, False)], 1000))

    print("\n[Unit 2] Manual parser")
    print(parse_raw_log_line('Acc101,"SAVINGS, PREMIUM","He said ""hello"""'))
    audit = create_audit_filter(100)
    print("Audit accepted:", audit({"amount": "150"}), "| count:", audit.get_count())
    print("Audit rejected:", audit({"amount": "20"}), "| count:", audit.get_count())
    positional = build_positional_filters(["Acc101", "DEPOSIT"])
    print("Positional filters:", [fn(("Acc101", "DEPOSIT")) for fn in positional])

    print("\n[Unit 3] Reverse index and in-place queue")
    raw_db = {
        "BRANCH_01": [("Acc101", {"DEPOSIT", "UPI"}), ("Acc102", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
    }
    print("Reverse index:", build_reverse_index(raw_db))
    queue = [(3, 1), [2, 9, 4], {1, 2, 3, 4}, 7, 7, 8]
    old_id = id(queue)
    clean_transaction_queue(queue)
    print("Queue:", queue, "| same object:", old_id == id(queue))

    print("\n[Unit 4] File update and custom exceptions")
    create_sample_database()
    print("Custom hierarchy:", issubclass(CorruptedRecordError, BaseSystemError),
          issubclass(OutOfBoundsError, BaseSystemError),
          issubclass(InsufficientBalanceError, BaseSystemError))
    print("Sample accounts.db created if missing. Use update_account_record('Acc101', 100).")

    print("\n[Unit 5] Encapsulation and polymorphism")
    savings = SavingsAccount("SAV-1", 5000)
    current = CurrentAccount("CUR-1", 500)
    credit = CreditAccount("CRD-1", 3000)
    print("Private balance through mangled name:", savings._Account__balance)
    try:
        print(savings.__balance)
    except AttributeError:
        print("Direct obj.__balance access correctly fails.")
    execute_batch_settlement([savings, current, credit], 100)
    print("Total account objects:", Account.total_accounts)

    print("\nInteractive mode is optional. Run command_loop() to start it.")
    print("To test file updating, call update_account_record('Acc101', 100).")


if __name__ == "__main__":
    run_demonstrations()
