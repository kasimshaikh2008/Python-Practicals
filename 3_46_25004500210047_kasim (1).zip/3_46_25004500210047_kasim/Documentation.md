# PTMAE — Documentation

**Project:** Pure Python Transactional Micro-Banking & Audit Engine  
**Document ID:** PTMAE-SRS-1.0  
**Course:** Python Programming (Units 1–5)  
**Files:** `main.py` and `Documentation.md`

## 1. Project overview

PTMAE is a command-line banking demonstration written in Python 3.x. It demonstrates loops, arithmetic, manual parsing, closures, lambdas, comprehensions, in-place list processing, text-file handling, custom exceptions, classes, encapsulation, inheritance, and polymorphism.

The program uses no third-party packages. Its only import is `datetime`, which is permitted by the supplied SRS. It does not use a database engine.

## 2. How to run

1. Save `main.py` and `Documentation.md` in the same folder.
2. Open a terminal in that folder.
3. Run:

   ```bash
   python main.py
   ```

4. The program runs demonstrations for Units 1–5 and creates `accounts.db` if it does not already exist.
5. To start the interactive command loop, open Python and call `command_loop()` after importing `main`, or temporarily add `command_loop()` beneath the demonstration call.
6. To test a file update from Python, use `update_account_record("Acc101", 100)`.

The program may create `accounts.db`, `ledger.txt`, and `corrupted.log` in its working directory.

## 3. Architecture diagram

```text
                 +-------------------------+
                 |      PTMAE main.py      |
                 +------------+------------+
                              |
          +-------------------+-------------------+
          |                   |                   |
  +-------v-------+   +-------v-------+   +-------v-------+
  | Unit 1        |   | Unit 2        |   | Unit 3        |
  | State / loops |   | Parser/closure|   | Reverse index |
  | Arithmetic    |   | Lambda filters|   | In-place queue|
  +---------------+   +---------------+   +---------------+
          |                   |                   |
          +-------------------+-------------------+
                              |
                    +---------v---------+
                    | Unit 4            |
                    | File update/logs  |
                    | Custom exceptions|
                    +---------+---------+
                              |
                    +---------v---------+
                    | Unit 5            |
                    | Account hierarchy |
                    | Polymorphic batch |
                    +-------------------+
```

## 4. Class diagram

```text
                 BaseSystemError (Exception)
                  /        |          \
                 /         |           \
 CorruptedRecordError  OutOfBoundsError  InsufficientBalanceError


                         Account
                 +----------------------+
                 | - __balance          |
                 | # _account_id        |
                 | + total_accounts     |
                 +----------------------+
                    /       |        \
                   /        |         \
          SavingsAccount CurrentAccount CreditAccount
```

- `-` means private.
- `#` means protected by naming convention.
- `+` means public.
- `SavingsAccount` preserves a minimum balance of 1000.
- `CurrentAccount` allows an overdraft up to its private limit.
- `CreditAccount` applies a 2.5% surcharge before settlement.

## 5. Module summary

### Unit 1 — State control engine

- `compound_interest()` calculates compound interest with arithmetic operators and a loop.
- `penalty_fee()` calculates a percentage fee.
- `trajectory_guard()` stops processing when the balance is below the safety threshold or a termination flag is set.
- `command_loop()` provides an interactive CLI with nested loops and input validation.

### Unit 2 — Parser and closures

- `parse_raw_log_line()` parses delimiters manually by index. Delimiters inside quoted fields are retained, doubled quotes become a single quote, and empty/trailing fields are preserved.
- `create_audit_filter()` returns a nested function using `nonlocal` to count accepted records. Each created filter has an independent counter.
- `build_positional_filters()` binds `k=k` in each lambda to avoid late binding.

### Unit 3 — Reverse index and in-place queue

- `build_reverse_index()` maps each service tag to sorted, unique `(account_id, branch_id)` pairs.
- `clean_transaction_queue()` mutates the original top-level list, converts tuple entries to lists, removes even integers from sets, sorts nested lists descending, and removes duplicate primitive values while preserving the first occurrence.
- The queue function returns the same list object; it does not bind the parameter to a replacement top-level list.

### Unit 4 — File modifier and logs

- `update_account_record()` opens `accounts.db` in `r+` mode and uses `tell()` and `seek()` to locate and update a matching account.
- When a record changes length, `_shift_file_tail()` moves the trailing content in chunks and truncates the file when needed.
- Invalid records are appended to `corrupted.log` with their line numbers.
- Successful updates are appended to `ledger.txt` with a timestamp.
- A `finally` block reports processed and rejected record counts.
- The program defines `BaseSystemError`, `CorruptedRecordError`, `OutOfBoundsError`, and `InsufficientBalanceError`.

### Unit 5 — Object-oriented settlement

- `Account` stores its balance in private `__balance`, uses protected `_account_id`, and tracks `total_accounts`.
- The `balance` and `account_id` properties validate assignments.
- Subclasses use `super().__init__()` and override `process_settlement()`.
- `execute_batch_settlement()` catches errors separately for each account so one rejected settlement does not stop later accounts.
- Demonstration code shows name mangling through `_Account__balance` and shows that `obj.__balance` is not a valid public attribute.

## 6. State and scope tracking table

| Name | Scope / visibility | Purpose |
|---|---|---|
| `audited_count` | Enclosing local variable | Closure state maintained with `nonlocal` |
| `k` in `build_positional_filters` | Loop local / lambda default | Each lambda retains its own position |
| `Account.__balance` | Private, name-mangled | Stores the account balance |
| `Account._account_id` | Protected by convention | Stores the account identifier |
| `Account.total_accounts` | Class attribute | Counts constructed account objects |
| `CurrentAccount.__overdraft_limit` | Private, name-mangled | Maximum permitted overdraft |
| `CreditAccount.__credit_limit` | Private, name-mangled | Maximum permitted credit balance |
| `data_list` | Function parameter | Mutated in place; object identity is preserved |
| `file_obj` | Local file handle | Accesses account records with `r+` |

There are no global variables used to transfer state into closures.

## 7. Module compliance checklist

| SRS topic | Implemented in |
|---|---|
| Nested-loop CLI and arithmetic interest | `command_loop`, `compound_interest` |
| Penalty fee calculation | `penalty_fee` |
| Short-circuit trajectory guard | `trajectory_guard` |
| Manual quoted-line parser | `parse_raw_log_line` |
| Closure with `nonlocal` counter | `create_audit_filter` |
| Lambda late-binding prevention | `build_positional_filters` |
| Dictionary-comprehension reverse index | `build_reverse_index` |
| In-place queue normalization | `clean_transaction_queue` |
| Custom exception hierarchy | `BaseSystemError` and subclasses |
| `r+`, `tell`, `seek`, chunk shifting | `update_account_record`, `_shift_file_tail` |
| Dual-stream logging | `ledger.txt`, `corrupted.log` |
| Private/protected/class attributes | `Account` hierarchy |
| Polymorphic settlement and fault isolation | `execute_batch_settlement` |
| Demonstration code | `run_demonstrations` |

## 8. Sample data format

`accounts.db` uses one comma-separated record per line:

```text
Acc101,SAVINGS,5200.00
Acc102,CURRENT,2500.00
Acc103,CREDIT,9000.00
Acc104,SAVINGS,1500.00
```

Each record contains account ID, account type, and balance. Supported types are `SAVINGS`, `CURRENT`, and `CREDIT`.

## 9. Notes and limitations

- This is an educational assignment demonstration, not production banking software.
- The sample database is plain text and has no authentication, encryption, concurrent access protection, or real financial safeguards.
- The parser intentionally handles the quote and delimiter rules described in the assignment; it is not intended to implement every feature of a full CSV standard.
- Review the instructor's exact acceptance examples before submission, particularly the expected behaviour of queue cleanup and file record shifting.
